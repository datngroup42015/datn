<?php

$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openXBannerTypes','ext'=>'zip');
$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openXDeliveryLimitations','ext'=>'zip');
$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openX3rdPartyServers','ext'=>'zip');
$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openXReports','ext'=>'zip');
$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openXDeliveryCacheStore','ext'=>'zip');
$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openXMaxMindGeoIP','ext'=>'zip');
$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openXInvocationTags','ext'=>'zip');
$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openXDeliveryLog','ext'=>'zip');
$aDefaultPlugins[] = array('path'=>MAX_PATH.'/etc/plugins/','name'=>'openXVideoAds','ext'=>'zip');

?>